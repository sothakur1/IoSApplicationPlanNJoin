//
//  TaskViewModel.swift
//  PlanNJoin
//
//  Created by Rahul Ravikanti on 5/3/24.
//
import Foundation
import Combine
import Firebase

class TasksViewModel: ObservableObject {
    @Published var tasks = [Task]()
    private var db = Firestore.firestore()
    
    init() {
        
        loadTasksByEmail()
        
    }
    
    
    
    public func loadTasksByEmail() {
        guard let userID = Auth.auth().currentUser?.uid else {
            print("No user logged in")
            return
        }
        print("User ID: \(userID)")
        
        let db = Firestore.firestore()
        
        // First, access the specific user document by userID to fetch the email
        db.collection("users").document(userID).getDocument { [weak self] (documentSnapshot, error) in
            if let error = error {
                print("Error fetching user document: \(error.localizedDescription)")
                return
            }
            
            guard let document = documentSnapshot, document.exists, let email = document.get("email") as? String else {
                print("Document does not exist or email field is missing")
                return
            }
            
            print("Email: \(email)")
            
            // Now, using the fetched email to load tasks
            db.collection("tasks")
                .whereField("assignedTo", isEqualTo: email)
                .addSnapshotListener { (querySnapshot, error) in
                    if let error = error {
                        print("Error getting tasks: \(error.localizedDescription)")
                        return
                    }
                    
                    guard let documents = querySnapshot?.documents else {
                        print("No documents found")
                        return
                    }
                                        
                                        self?.tasks = documents.compactMap { document in
                                            try? document.data(as: Task.self)
                                        }
                                    }
                            }
                        }
                        
                     
                        
                        func updateTaskCompletion(taskId: String, isCompleted: Bool) {
                                print("Updating taskID \(taskId) to \(isCompleted)")
                                
                                // Query to find tasks by 'id' field
                                db.collection("tasks").whereField("id", isEqualTo: taskId).getDocuments { [weak self] (querySnapshot, error) in
                                    guard let documents = querySnapshot?.documents, !documents.isEmpty else {
                                        if let error = error {
                                            print("Error finding tasks: \(error.localizedDescription)")
                                        } else {
                                            print("No tasks found with id \(taskId)")
                                        }
                                        return
                                    }
                                    
                                    // Update each document found
                                    for document in documents {
                                        self?.db.collection("tasks").document(document.documentID).updateData([
                                            "isCompleted": isCompleted
                                        ]) { error in
                                            if let error = error {
                                                print("Error updating task: \(error.localizedDescription)")
                                            } else {
                                                print("Task \(document.documentID) successfully updated.")
                                            }
                                        }
                                    }
                                    
                                    DispatchQueue.main.async {
                                        self?.refreshTasks()
                                    }
                                }
                            }
    func refreshTasks() {
                // Assuming you have a method to reload tasks here, triggering the view to update
                loadTasksByEmail()
            }
    }

