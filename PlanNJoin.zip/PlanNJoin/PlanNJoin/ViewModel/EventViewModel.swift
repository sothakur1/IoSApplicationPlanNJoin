//
//  EventViewModel.swift
//  PlanNJoin
//
//  Created by Rahul Ravikanti on 5/1/24.
//

import Foundation
import FirebaseFirestore
import FirebaseFirestoreSwift

class EventViewModel: ObservableObject {
    @Published var events: [Event] = []

    
     
      func fetchEvents() {
          let db = Firestore.firestore()
          db.collection("events").getDocuments { (snapshot, error) in
              if let error = error {
                  print("Error fetching events: \(error)")
                  return
              }

              self.events = snapshot?.documents.compactMap { document -> Event? in
                  try? document.data(as: Event.self)
              } ?? []
          }
      }
}


