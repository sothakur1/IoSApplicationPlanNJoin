//
//  EditEventViewModel.swift
//  PlanNJoin
//
//  Created by Rahul Ravikanti on 5/3/24.
//

import Foundation
import Combine
import Firebase

class EditEventViewModel: ObservableObject {
    @Published var event: Event
    @Published var tasks: [Task] = []
    @Published var attendees: [String] = []

    private var manageEventVM = ManageEventViewModel()
    private var db = Firestore.firestore()
    
    init(event: Event) {
        self.event = event
        // Convert the task titles from event.tasks to Task instances if necessary.
        // Assuming event.tasks is already an array of Task objects
       // self.tasks = event.tasks
        loadTasks(taskIds: event.tasks)//self.attendees = event.attendeeEmails
    }
    private func loadTasks(taskIds: [String]) {
           // Assume Task has an initializer that can create a Task from Firestore document
           for taskId in taskIds {
               db.collection("tasks").document(taskId).getDocument { [weak self] (document, error) in
                   if let document = document, document.exists {
                       if let task = try? document.data(as: Task.self) {
                           DispatchQueue.main.async {
                               self?.tasks.append(task)
                           }
                       }
                   } else {
                       print("Document does not exist or error: \(error?.localizedDescription ?? "Unknown error")")
                   }
               }
           }
       }
    func addAttendee(email: String) {
        attendees.append(email)
    }

    func addTask(title: String) {
        // Assuming you want to add a task with minimal information and update later
        let newTask = Task(title: title, description: "", isCompleted: false)
        tasks.append(newTask)
    }

    func updateTask(updatedTask: Task) {
        if let index = tasks.firstIndex(where: { $0.id == updatedTask.id }) {
            tasks[index] = updatedTask
        }
    }

    func saveEventChanges() {
        // Implement the logic to save the changes to Firestore or your data store
        // This would include saving the event details, updated tasks, and attendees
        manageEventVM.addOrUpdateEvent(event)
        print("Event saved")
    }
    
    
}
