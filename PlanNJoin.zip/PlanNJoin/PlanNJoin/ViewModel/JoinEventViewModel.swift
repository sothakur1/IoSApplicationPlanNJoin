//
//  JoinEventViewModel.swift
//  PlanNJoin
//
//  Created by Yash Patel on 4/23/24.
//

import Foundation
import Firebase
import FirebaseFirestoreSwift

class JoinEventViewModel: ObservableObject {
    @Published var events: [Event] = []
    @Published var loadingError: String?
    @Published var showAlert: Bool = false
    private var authViewModel: AuthenticationViewModel

    init(authViewModel: AuthenticationViewModel) {
        self.authViewModel = authViewModel
    }

    func loadEvents() {
        let db = Firestore.firestore()
        let today = Date()
        db.collection("events")
            .whereField("isPublic", isEqualTo: true)
            .whereField("dateTime", isGreaterThan: today)
            .order(by: "dateTime", descending: false)
            .getDocuments { [weak self] (querySnapshot, error) in
                guard let self = self else { return }
                if let error = error {
                    self.loadingError = "Failed to fetch events: \(error.localizedDescription)"
                    self.showAlert = true
                } else if let documents = querySnapshot?.documents, !documents.isEmpty {
                    self.events = documents.compactMap { document -> Event? in
                        try? document.data(as: Event.self)
                    }.filter { !$0.attendeeEmails.contains(self.authViewModel.email) }
                    if self.events.isEmpty {
                        self.loadingError = "No events available to join."
                        self.showAlert = true
                    }
                } else {
                    self.loadingError = "No events found in the database."
                    self.showAlert = true
                }
            }
    }

    func joinEvent(_ event: Event) {
        guard let eventId = event.id else {
            self.loadingError = "Event does not have a valid ID."
            self.showAlert = true
            return
        }

        let db = Firestore.firestore()
        db.collection("events").document(eventId).updateData([
            "attendeeEmails": FieldValue.arrayUnion([self.authViewModel.email])
        ]) { [weak self] error in
            guard let self = self else { return }
            if let error = error {
                self.loadingError = "Failed to join event: \(error.localizedDescription)"
                self.showAlert = true
            } else {
                print("User added to event successfully")
                self.loadEvents()  // Refresh the events list
            }
        }
    }
}
