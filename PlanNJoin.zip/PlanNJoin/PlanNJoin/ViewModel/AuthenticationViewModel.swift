//
//  AuthenticationViewModel.swift
//  PlanNJoin
//
//  Created by Yash Patel on 3/19/24.
//

import Foundation
import FirebaseAuth

class AuthenticationViewModel: ObservableObject {
    @Published var isUserAuthenticated: AuthState = .undefined
    @Published var isShowingSignup = false
    var email: String = ""
    var password: String = ""
    var name: String = ""
    var phoneNumber: String = ""
    
    init() {
        checkAuthentication()
    }
    
    func checkAuthentication() {
        if Auth.auth().currentUser != nil {
            isUserAuthenticated = .signedIn
        } else {
            isUserAuthenticated = .signedOut
        }
    }
    
    func login() {
        AuthenticationService.shared.loginWithEmail(email: email, password: password) { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let user):
                    print("Successfully logged in as \(user.email ?? "unknown")")
                    self?.isUserAuthenticated = .signedIn
                case .failure(let error):
                    print("Login error: \(error.localizedDescription)")
                }
            }
        }
    }
    
    func signUp() {
        AuthenticationService.shared.signUpWithEmail(name: name, phoneNumber: phoneNumber, email: email, password: password) { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let user):
                    print("Successfully signed up as \(user.email ?? "unknown")")
                    self?.isUserAuthenticated = .signedIn
                case .failure(let error):
                    print("Signup error: \(error.localizedDescription)")
                }
            }
        }
    }
    
    func logOut() {
        do {
            try Auth.auth().signOut()
            DispatchQueue.main.async {
                self.isUserAuthenticated = .signedOut
            }
        } catch let signOutError as NSError {
            print("Error signing out: \(signOutError)")
        }
    }
    
    enum AuthState {
        case undefined, signedOut, signedIn
    }
}
