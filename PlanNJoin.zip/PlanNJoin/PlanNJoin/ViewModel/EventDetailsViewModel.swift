//
//  TaskDetailsViewModel.swift
//  PlanNJoin
//
//  Created by Rahul Ravikanti on 5/3/24.
//

import Foundation
import Firebase
class EventDetailsViewModel: ObservableObject {
    @Published var detailedTasks: [Task] = []

    // Function to fetch tasks based on IDs
    func fetchTasks(for taskIDs: [String]) {
        print(taskIDs)
        
        let db = Firestore.firestore()
        var fetchedTasks: [Task] = []
        let group = DispatchGroup()
        
         for id in taskIDs {
             group.enter()
             db.collection("tasks").whereField("id", isEqualTo: id).getDocuments { (querySnapshot, error) in
                 defer { group.leave() }
                 if let error = error {
                     print("Error fetching tasks for ID \(id): \(error)")
                     return
                 }
                 
                 guard let documents = querySnapshot?.documents else {
                     print("No documents found for ID \(id)")
                     return
                 }
                 
                 for document in documents {
                     do {
                         let task = try document.data(as: Task.self)
                         fetchedTasks.append(task)
                     } catch {
                         print("Error decoding task: \(error)")
                     }
                 }
             }
         }
        
        group.notify(queue: .main) {
            self.detailedTasks = fetchedTasks
        }
        
    }
}
