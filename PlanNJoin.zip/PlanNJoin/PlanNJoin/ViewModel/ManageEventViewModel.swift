//
//  ManageEventViewModel.swift
//  PlanNJoin
//
//  Created by Rahul Ravikanti on 5/3/24.
//


import Foundation
import FirebaseFirestore
import FirebaseAuth

class ManageEventViewModel: ObservableObject {
    @Published var events: [Event] = []
    private var db = Firestore.firestore()

    
    
    func fetchEvents(forEmail email: String? = nil) {
        print("email id in fetch Events: \(email ?? "<default value>")")
        db.collection("events")
            .whereField("attendeeEmails", arrayContains: email)
            .addSnapshotListener { [weak self] (querySnapshot, error) in
                if let error = error {
                    print("Error getting events: \(error.localizedDescription)")
                    return
                }
                
                guard let documents = querySnapshot?.documents else {
                    print("No documents")
                    return
                }
                
                self?.events = documents.compactMap { queryDocumentSnapshot -> Event? in
                    let data = queryDocumentSnapshot.data()
                    let id = queryDocumentSnapshot.documentID
                    let title = data["title"] as? String ?? ""
                    let category = data["category"] as? Category // Assuming Category is Codable and can be directly decoded
                    let location = data["location"] as? String ?? ""
                    let dateTime = (data["dateTime"] as? Timestamp)?.dateValue() ?? Date()
                    let isPublic = data["isPublic"] as? Bool ?? false
                    let description = data["description"] as? String ?? ""
                    let tasks = data["tasks"] as? [String] ?? []
                    let attendeeEmails = data["attendeeEmails"] as? [String] ?? []

                    return Event(id: id, title: title, category: category, location: location, dateTime: dateTime, isPublic: isPublic, description: description, tasks: tasks, attendeeEmails: attendeeEmails)
                }
            }

        }
     

    // Function to add or update an event
    func addOrUpdateEvent(_ event: Event) {
        var tasksData: [[String: Any]] = []
        for taskId in event.tasks {
               // Assuming ⁠ taskId ⁠ is just an ID or title, not a full Task object
               let taskDict: [String: Any] = [
                   "id": taskId, // Example assumption: taskId is the unique identifier
                   "title": taskId, // Assuming title and ID are the same
                   "description": "",
                   "assignedTo": "",
                   "isCompleted": false
               ]
                             tasksData.append(taskDict)
                         }
                      
                      
                      let eventData = [
                          "title": event.title,
                          "category": event.category?.id ?? "",  // Assuming ⁠ Category ⁠ has an ⁠ id ⁠ field
                          "location": event.location,
                          "dateTime": Timestamp(date: event.dateTime),
                          "isPublic": event.isPublic,
                          "description": event.description,
                          "tasks": tasksData,
                          "attendeeEmails": event.attendeeEmails
                      ] as [String: Any]

                      print("Updating Firestore with eventData: \(eventData)")
                      
                      if let eventId = event.id {
                          db.collection("events").document(eventId).setData(eventData) { err in
                              if let err = err {
                                  print("Error updating document: \(err)")
                              } else {
                                  print("Document successfully updated")
                              }
                          }
                      } else {
                          var ref: DocumentReference? = nil
                          ref = db.collection("events").addDocument(data: eventData) { err in
                              if let err = err {
                                  print("Error adding document: \(err)")
                              } else {
                                  print("Document added with ID: \(ref!.documentID)")
                              }
                          }
                      }
                  }


                  // Function to delete an event
                  func deleteEvent(_ eventId: String) {
                      db.collection("events").document(eventId).delete() { err in
                          if let err = err {
                              print("Error removing document: \(err)")
                          } else {
                              print("Document successfully removed")
                          }
                      }
                  }
    
    func loadEventsByEmail() {
            guard let userID = Auth.auth().currentUser?.uid else {
                print("No user logged in")
                return
            }
            print("User ID: \(userID)")

            db.collection("users").document(userID).getDocument { [weak self] (documentSnapshot, error) in
                if let error = error {
                    print("Error fetching user document: \(error.localizedDescription)")
                    return
                }

                guard let document = documentSnapshot, document.exists, let email = document.get("email") as? String else {
                    print("Document does not exist or email field is missing")
                    return
                }

                print("Email: \(email)")

                self?.fetchEvents(forEmail: email)
            }
        }
    
    
    
    
    
    
              }

/*
 public func loadEventsByEmail() {
     guard let userID = Auth.auth().currentUser?.uid else {
         print("No user logged in")
         return
     }
     print("User ID: \(userID)")
     
     let db = Firestore.firestore()
     
     // First, access the specific user document by userID to fetch the email
     db.collection("users").document(userID).getDocument { [weak self] (documentSnapshot, error) in
         if let error = error {
             print("Error fetching user document: \(error.localizedDescription)")
             return
         }
         
         guard let document = documentSnapshot, document.exists, let email = document.get("email") as? String else {
             print("Document does not exist or email field is missing")
             return
         }
         
         print("Email: \(email)")
         
         // Now, using the fetched email to load events
         db.collection("events")
             .whereField("participantEmails", arrayContains: email)
             .addSnapshotListener { (querySnapshot, error) in
                 if let error = error {
                     print("Error getting events: \(error.localizedDescription)")
                     return
                 }
                 
                 guard let documents = querySnapshot?.documents else {
                     print("No documents found")
                     return
                 }
                 
                 self?.events = documents.compactMap { document in
                     try? document.data(as: Event.self)
                 }
             }
     }
 }

 */


// Function to fetch events
/*
 func fetchEvents() {
     print("try to check ")
     db.collection("events")
         .order(by: "dateTime")
         .addSnapshotListener { (querySnapshot, error) in
             guard let documents = querySnapshot?.documents else {
                 print("No documents")
                 return
             }

             self.events = documents.map { queryDocumentSnapshot -> Event in
                 let data = queryDocumentSnapshot.data()
                 let id = queryDocumentSnapshot.documentID
                 let title = data["title"] as? String ?? ""
                 let category = data["category"] as? Category // Assuming Category is Codable and can be directly decoded
                 let location = data["location"] as? String ?? ""
                 let dateTime = (data["dateTime"] as? Timestamp)?.dateValue() ?? Date()
                 let isPublic = data["isPublic"] as? Bool ?? false
                 let description = data["description"] as? String ?? ""
                 let tasks = data["tasks"] as? [String] ?? []
                 let attendeeEmails = data["attendeeEmails"] as? [String] ?? []

                 return Event(id: id, title: title, category: category, location: location, dateTime: dateTime, isPublic: isPublic, description: description, tasks: tasks, attendeeEmails: attendeeEmails)
             }
         }
 }
 */
