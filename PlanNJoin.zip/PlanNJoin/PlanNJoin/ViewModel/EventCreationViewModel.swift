//
//  EventCreationViewModel.swift
//  PlanNJoin
//
//  Created by Yash Patel on 4/23/24.
//


import Foundation
import Firebase

class EventCreationViewModel: ObservableObject {
    private var authViewModel: AuthenticationViewModel

        init(authViewModel: AuthenticationViewModel) {
            self.authViewModel = authViewModel
        }
    
    @Published var title: String = ""
    @Published var selectedCategoryID: String?
    @Published var location: String = ""
    @Published var dateTime: Date = Date()
    @Published var isPublic: Bool = false
    @Published var description: String = ""
    @Published var attendeeEmail: String = ""
    @Published var attendeeEmails: [String] = []
    @Published var taskTitle: String = ""
    @Published var assignedTo: String = ""
    @Published var taskDescription: String = ""
    @Published var tasks: [String] = []
    @Published var localTasks: [Task] = []

    // Categories remain hardcoded in the ViewModel for simplicity
    @Published var categories: [Category] = [
        Category(id: "1", name: "Birthday"),
        Category(id: "2", name: "Movie"),
        Category(id: "3", name: "Party"),
        Category(id: "4", name: "Outing"),
        Category(id: "5", name: "Other")
    ]

    
    func addTaskToFirestore(task: Task) {
        let db = Firestore.firestore()
        db.collection("tasks").addDocument(data: [
            "title": task.title,
            "assignedTo": task.assignedTo ?? "",
            "description": task.description,
            "isCompleted": task.isCompleted,
            "id":task.id
        ]) { err in
            if let err = err {
                print("Error adding task: \(err)")
            } else {
                print("Task successfully added")
                self.tasks.append(task.id)  // Keep this to reference tasks in the event creation
            }
        }
    }
    
    

    func createEvent() {
        if !attendeeEmails.contains(authViewModel.email) {
            attendeeEmails.append(authViewModel.email)
        }

        let db = Firestore.firestore()
        db.collection("events").addDocument(data: [
            "title": title,
            "categoryID": selectedCategoryID ?? "Other",
            "location": location,
            "dateTime": dateTime,
            "isPublic": isPublic,
            "description": description,
            "attendeeEmails": attendeeEmails,
            "tasks": tasks
        ]) { err in
            if let err = err {
                print("Error adding event: \(err)")
            } else {
                print("Event created successfully")
                self.resetFields()
            }
        }
    }
     
     
    
    
     /*
      func createEvent() {
          if !attendeeEmails.contains(authViewModel.email) {
              attendeeEmails.append(authViewModel.email)
          }

          let db = Firestore.firestore()
          
          // Prepare tasks data
          let tasksData = tasks.map { task -> [String: Any] in
              return [
                  "title": task.title,
                  "assignedTo": task.assignedTo ?? "",
                  "description": task.description,
                  "isCompleted": task.isCompleted
              ]
          }
          
          // Prepare the event data
          let eventData: [String: Any] = [
              "title": title,
              "categoryID": selectedCategoryID ?? "Other",
              "location": location,
              "dateTime": dateTime,
              "isPublic": isPublic,
              "description": description,
              "attendeeEmails": attendeeEmails,
              "tasks": tasksData  // Include task dictionaries directly
          ]
          
          // Add the document
          db.collection("events").addDocument(data: eventData) { err in
              if let err = err {
                  print("Error adding event: \(err)")
              } else {
                  print("Event created successfully")
                  self.resetFields()
              }
          }
      }

      */
     

    func resetFields() {
        title = ""
        selectedCategoryID = nil
        location = ""
        dateTime = Date()
        isPublic = false
        description = ""
        attendeeEmail = ""
        attendeeEmails.removeAll()
        taskTitle = ""
        assignedTo = ""
        taskDescription = ""
        tasks.removeAll()
        localTasks.removeAll()
    }
}

