//
//  MovieListViewModel.swift
//  PlanNJoin
//
//  Created by Rahul Ravikanti on 5/1/24.
//

import Foundation
import Foundation

class MovieListViewModel: ObservableObject {
    @Published var movies: [Movie] = []
    private var category: MovieCategory
    
    init(category: MovieCategory) {
        self.category = category
        fetchMovies()
    }
    
    func fetchMovies() {
        // Assuming NetworkService().fetchMovies(completion:) is correctly implemented
        NetworkService().fetchMovies(category: category) { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let fetchedMovies):
                    self?.movies = self?.filterDeletedMovies(from: fetchedMovies) ?? []
                case .failure(let error):
                    print(error.localizedDescription)
                }
            }
        }
    }
    
    private func filterDeletedMovies(from movies: [Movie]) -> [Movie] {
        guard let deletedMovieIDs = UserDefaults.standard.array(forKey: "DeletedMovieIDs") as? [Int] else {
            return movies
        }
        return movies.filter { !deletedMovieIDs.contains($0.id) }
    }
    
    func deleteMovies(atOffsets offsets: IndexSet) {
        let idsToDelete = offsets.map { self.movies[$0].id }
        var currentDeletedIDs = UserDefaults.standard.array(forKey: "DeletedMovieIDs") as? [Int] ?? []
        currentDeletedIDs.append(contentsOf: idsToDelete)
        UserDefaults.standard.set(currentDeletedIDs, forKey: "DeletedMovieIDs")
        
        movies.remove(atOffsets: offsets)
    }
}
