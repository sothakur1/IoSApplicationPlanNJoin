//
//  UserProfileEditViewModel.swift
//  PlanNJoin
//
//  Created by Yash Patel on 4/22/24.
//

import Foundation
import FirebaseStorage
import FirebaseFirestore
import FirebaseAuth
import UIKit

class UserProfileEditViewModel: ObservableObject {
    @Published var profileImage: UIImage? = UIImage(systemName: "person.fill")
    @Published var username: String = ""
    @Published var bio: String = ""
    @Published var phoneNumber: String = ""
    @Published var dateOfBirth: String = ""

    func fetchUserProfile() {
        guard let userID = Auth.auth().currentUser?.uid else {
            print("User not logged in")
            return
        }

        let db = Firestore.firestore()
        db.collection("users").document(userID).getDocument { [weak self] (document, error) in
            guard let self = self else { return }
            if let document = document, document.exists {
                let data = document.data()
                self.username = data?["username"] as? String ?? ""
                self.bio = data?["bio"] as? String ?? ""
                self.phoneNumber = data?["phoneNumber"] as? String ?? ""
                self.dateOfBirth = data?["dateOfBirth"] as? String ?? ""
                
                if let imageUrl = data?["profileImageUrl"] as? String, let url = URL(string: imageUrl) {
                    self.downloadImage(from: url)
                }
            } else {
                print("Document does not exist")
            }
        }
    }

    func downloadImage(from url: URL) {
        URLSession.shared.dataTask(with: url) { [weak self] data, _, _ in
            guard let data = data, let self = self else { return }
            DispatchQueue.main.async {
                self.profileImage = UIImage(data: data)
            }
        }.resume()
    }

    func saveProfileData(image: UIImage?) {
        guard let imageData = image?.jpegData(compressionQuality: 0.4) else {
            print("Image data not available")
            return
        }
        
        uploadImageToFirebase(imageData) { [weak self] result in
            guard let self = self else { return }
            switch result {
            case .success(let url):
                self.saveUserProfileInfo(profileImageUrl: url.absoluteString)
            case .failure(let error):
                print("Upload failed, error: \(error)")
            }
        }
    }

    private func uploadImageToFirebase(_ imageData: Data, completion: @escaping (Result<URL, Error>) -> Void) {
        let storageRef = Storage.storage().reference()
        let userID = Auth.auth().currentUser?.uid ?? "unknown_user"
        let fileRef = storageRef.child("userProfileImages/\(userID)/\(UUID().uuidString).jpg")

        fileRef.putData(imageData, metadata: nil) { metadata, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            fileRef.downloadURL { (url, error) in
                if let error = error {
                    completion(.failure(error))
                } else if let url = url {
                    completion(.success(url))
                }
            }
        }
    }

    private func saveUserProfileInfo(profileImageUrl: String) {
        let db = Firestore.firestore()
        guard let userID = Auth.auth().currentUser?.uid else {
            print("User not logged in")
            return
        }

        db.collection("users").document(userID).setData([
            "username": username,
            "bio": bio,
            "profileImageUrl": profileImageUrl,
            "phoneNumber": phoneNumber,
            "dateOfBirth": dateOfBirth
        ], merge: true) { error in
            if let error = error {
                print("Error writing document: \(error)")
            } else {
                print("Document successfully written!")
            }
        }
    }

    func logOut() {
        do {
            try Auth.auth().signOut()
            print("Logged out successfully.")
        } catch let signOutError as NSError {
            print("Error signing out: \(signOutError)")
        }
    }
}
