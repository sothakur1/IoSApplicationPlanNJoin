//
//  PlanNJoinApp.swift
//  PlanNJoin
//
//  Created by Yash Patel on 3/19/24.
//

import SwiftUI

@main
struct PlanNJoinApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate
    @StateObject var authViewModel = AuthenticationViewModel()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(authViewModel)
        }
    }
}
