//
//  HomeView.swift
//  PlanNJoin
//
//  Created by Rahul Ravikanti on 5/1/24.
//

import Foundation
import SwiftUI


struct HomeView: View {
    @ObservedObject var myMovieNowPlaying = MovieListViewModel(category: MovieCategory.nowPlaying)
    @ObservedObject var myMoviePopular = MovieListViewModel(category: MovieCategory.popular)
    @ObservedObject var myMovieTopRated = MovieListViewModel(category: MovieCategory.topRated)
    @ObservedObject var myMovieUpComing = MovieListViewModel(category: MovieCategory.upcoming)
    @StateObject var eventViewModel = EventViewModel()
    @StateObject var eventDetailsViewModel = EventDetailsViewModel()
    //@ObservedObject var viewModel: EventViewModel
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    Text("Hello There,")
                        .font(.largeTitle)
                    Text("Got Bored, browse through some of the events")
                        .font(.headline)
                    
                    //EventScrollView
                    ScrollView(.horizontal, showsIndicators: false) {
                                                    HStack(spacing: 20) {
                                                        ForEach(eventViewModel.events) { event in
                                                            NavigationLink(destination: EventDetails(event: event, viewModel: eventDetailsViewModel)) {
                                                                EventRowView(event: event)
                                                            }
                                                        }
                                                    }
                                                    .padding()
                                                }
                    
                                                .onAppear {
                                                    eventViewModel.fetchEvents()
                                                }
                    
                    //2
                    
                    Text("Some of the movies you can plan")
                        .font(.headline)
                    
                    
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 10) {
                            ForEach(myMoviePopular.movies) { movie in
                                NavigationLink(destination: MovieDetailView(movie: movie)) {
                                    MovieRowView(movie: movie)
                                }
                                .buttonStyle(PlainButtonStyle()) // Prevents the default button style from interfering with the layout
                            }
                        }
                        .padding(.horizontal)
                    }
                    .onAppear {
                        myMoviePopular.fetchMovies()
                    }
                    
                    //3
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 10) {
                            ForEach(myMovieTopRated.movies) { movie in
                                NavigationLink(destination: MovieDetailView(movie: movie)) {
                                    MovieRowView(movie: movie)
                                }
                                .buttonStyle(PlainButtonStyle()) // Prevents the default button style from interfering with the layout
                            }
                        }
                        .padding(.horizontal)
                    }
                    .onAppear {
                        myMovieTopRated.fetchMovies()
                    }
                    
                    //4
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 10) {
                            ForEach(myMovieUpComing.movies) { movie in
                                NavigationLink(destination: MovieDetailView(movie: movie)) {
                                    MovieRowView(movie: movie)
                                }
                                .buttonStyle(PlainButtonStyle()) // Prevents the default button style from interfering with the layout
                            }
                        }
                        .padding(.horizontal)
                    }
                    .onAppear {
                        myMovieUpComing.fetchMovies()
                    }
 
                }
                .padding()
            }
            .background(Color.blue.opacity(0.2))
            .navigationBarTitle("Home", displayMode: .inline)
            .navigationBarItems(trailing: NavigationLink(destination: UserProfileEditView()) {
                Image(systemName: "person.crop.circle")
                    .imageScale(.large)
            })
            
        }
    }
}

 struct HomeView_Previews: PreviewProvider {
     static var previews: some View {
         let authViewModel = AuthenticationViewModel()
         
         return HomeView()
             .environmentObject(authViewModel)
     }
 }




 
