//
//  EventDetailView.swift
//  PlanNJoin
//
//  Created by Yash Patel on 4/22/24.
//

import SwiftUI
import Firebase
import FirebaseFirestoreSwift

struct EventDetailView: View {
    var event: Event
    @EnvironmentObject var authViewModel: AuthenticationViewModel

    var body: some View {
        VStack {
            Text(event.title).font(.largeTitle)
            Text(event.description).padding()
            Text("Location: \(event.location)")
            Text("Date: \(event.dateTime, formatter: JoinEventView.dateFormatter)")
            if !event.attendeeEmails.contains(authViewModel.email) {
                Button("Join Event") {
                    joinEvent()
                }
                .padding()
                .foregroundColor(.white)
                .background(Color.blue)
                .cornerRadius(10)
            }
        }
        .background(Color.blue.opacity(0.2))
        .navigationBarTitle("Event Details", displayMode: .inline)
    }

    private func joinEvent() {
        guard let eventId = event.id else {
            return // Handle error appropriately
        }
        let db = Firestore.firestore()
        db.collection("events").document(eventId).updateData([
            "attendeeEmails": FieldValue.arrayUnion([authViewModel.email])
        ]) { error in
            if let error = error {
                // Handle error appropriately
                print("Failed to join event: \(error.localizedDescription)")
            } else {
                print("User added to event successfully")
            }
        }
    }
    
    static let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter
    }()
}
