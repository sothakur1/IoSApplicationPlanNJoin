import SwiftUI

struct EventDetails: View {
    var event: Event
    @ObservedObject var viewModel: EventDetailsViewModel

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 10) {
                // Event Title and Date
                HStack {
                    Text(event.title)
                        .font(.title)
                        .fontWeight(.bold)
                    Spacer()
                    Text("\(event.dateTime, formatter: dateFormatter)")
                        .font(.subheadline)
                }
                .padding([.top, .horizontal])
                
                // Description Section
                Text("Description")
                    .font(.headline)
                    .padding(.horizontal)
                Text(event.description)
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(10)
                    .padding(.horizontal)
                
                // Attendees Section
                Text("Attendees")
                    .font(.headline)
                    .padding(.horizontal)
                
                VStack {
                    ForEach(event.attendeeEmails, id: \.self) { email in
                        Text(email)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.vertical, 8)
                            .padding(.horizontal)
                            .background(Color.white)
                            .overlay(
                                Rectangle()
                                    .frame(height: 1, alignment: .bottom)
                                    .foregroundColor(.gray), alignment: .bottom
                            )
                    }
                }
                .background(Color.white)
                .cornerRadius(10)
                .shadow(radius: 2)
                .padding(.horizontal)
                
                // Tasks Section
                Text("Tasks")
                    .font(.headline)
                    .padding(.horizontal)
                
                VStack(spacing: 0) {
                    ForEach(viewModel.detailedTasks, id: \.id) { task in
                        HStack {
                            VStack(alignment: .leading) {
                                Text(task.title)
                                            .frame(maxWidth: .infinity, alignment: .leading)
                                            .padding(.bottom, 4)
                                
                               // let descriptionText = "Description: " + task.description
                                Text("Description: \(task.description)")
                                                .font(.subheadline)
                                                .foregroundColor(.secondary)
                                                .lineLimit(nil)
                                
                                if let assignedTo = task.assignedTo {
                                    Text("Assigned to: " + assignedTo)
                                        .font(.subheadline)
                                        .foregroundColor(.secondary)
                                }
                            }
                            
                            Toggle(isOn: .constant(task.isCompleted)) {
                                Text("")
                            }
                            .toggleStyle(SwitchToggleStyle(tint: .green))
                            .padding(.trailing)
                        }
                        .background(Color.white)
                        .overlay(
                            Rectangle()
                                .frame(height: 1, alignment: .bottom)
                                .foregroundColor(.gray), alignment: .bottom
                        )


                    }
                }
                .background(Color.blue.opacity(0.2))
                .cornerRadius(10)
                .shadow(radius: 2)
                .padding(.horizontal)
                .onAppear {
                    viewModel.fetchTasks(for: event.tasks)
                }
                
            }
        }
        .background(Color.blue.opacity(0.2))
        .navigationBarTitle("Event Details", displayMode: .inline)
    }

    private var dateFormatter: DateFormatter {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .none
        return formatter
    }
}

