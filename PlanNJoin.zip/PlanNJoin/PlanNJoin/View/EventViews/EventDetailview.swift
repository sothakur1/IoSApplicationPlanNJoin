//
//  EventDetailview.swift
//  PlanNJoin
//
//  Created by Rahul Ravikanti on 5/1/24.
//

import Foundation
import SwiftUI

struct EventDetailView: View {
    var event: Event

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 10) {
                // Event Title and Date
                HStack {
                    Text(event.title)
                        .font(.title)
                        .fontWeight(.bold)
                    Spacer()
                    Text("\(event.dateTime, formatter: dateFormatter)")
                        .font(.subheadline)
                }
                .padding()

                // Description Section
                Text("Description")
                    .font(.headline)
                    .padding(.leading)
                Text(event.description)
                    .padding()

                // Attendees Section
                Text("Attendees")
                    .font(.headline)
                    .padding(.leading)
                ForEach(event.attendeeEmails, id: \.self) { email in
                    Text(email)
                        .padding(.horizontal)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                .padding(.vertical, 5)

                // Tasks Section
                Text("Tasks")
                    .font(.headline)
                    .padding(.leading)
                ForEach(event.tasks, id: \.self) { task in
                    HStack {
                        Text(task)
                        Spacer()
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundColor(.green)
                    }
                    .padding()
                }
            }
        }
        .navigationBarTitle("Event Details", displayMode: .inline)
    }

    private var dateFormatter: DateFormatter {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .none
        return formatter
    }
}

