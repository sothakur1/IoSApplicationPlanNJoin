//
//  EventView.swift
//  PlanNJoin
//
//  Created by Rahul Ravikanti on 5/1/24.
//

import Foundation
import SwiftUI

struct EventRowView: View {
    var event: Event

    var body: some View {
        VStack(alignment: .leading) {
            Text(event.title)
                .font(.headline)
                .frame(width: 200, alignment: .leading)
                .lineLimit(1) // Ensures the text does not overflow

            Text(event.location)
                .font(.subheadline)
                .foregroundColor(.gray)
                .lineLimit(1) // Ensures the text does not overflow

            Text("Date: \(event.dateTime, formatter: itemFormatter)")
                .font(.caption)
                .lineLimit(1) // Ensures the text does not overflow
        }
        .padding()
        .background(Color.white) // Set background color of VStack to white
        .cornerRadius(10)
        .shadow(radius: 5)
        .frame(width: 220, height: 180)
    }
    
    private var itemFormatter: DateFormatter {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .short
        return formatter
    }
}



 import SwiftUI
 import FirebaseFirestore

 struct EventsListView: View {
     @StateObject var viewModel = EventViewModel()

     var body: some View {
         ScrollView(.horizontal, showsIndicators: false) {
             HStack(spacing: 20) {
                 ForEach(viewModel.events) { event in
                     EventRowView(event: event)
                 }
             }
             .padding()
         }
         .onAppear {
             viewModel.fetchEvents()
         }
     }
 }



