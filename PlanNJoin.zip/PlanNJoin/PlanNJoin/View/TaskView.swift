//
//  TaskView.swift
//  PlanNJoin
//
//  Created by Rahul Ravikanti on 5/3/24.
//

import SwiftUI
import Firebase
struct TasksView: View {
    @ObservedObject var viewModel = TasksViewModel()

    var body: some View {
        NavigationView {
            List(viewModel.tasks) { task in
                VStack(alignment: .leading) {
                    Text(task.title)
                        .font(.headline)
                    Text(task.description)
                        .font(.subheadline)
                    
                    
                    HStack {
                        Text(task.title)
                        Spacer()
                        Toggle(isOn: Binding(
                            get: { task.isCompleted },
                            set: { newValue in
                                viewModel.updateTaskCompletion(taskId: task.id, isCompleted: newValue)
                            }
                        )) {
                            Text(task.isCompleted ? "Completed" : "Pending")
                        }
                        .toggleStyle(SwitchToggleStyle(tint: .green))
                    }
                    
                }
            }
            .onAppear {
                viewModel.loadTasksByEmail()
            }
            
            .navigationBarTitle("My Tasks")
        }
        .background(Color.blue.opacity(0.2))
        //
        
      
       
    }
}

struct TasksView_Previews: PreviewProvider {
    static var previews: some View {
        TasksView()
    }
}
