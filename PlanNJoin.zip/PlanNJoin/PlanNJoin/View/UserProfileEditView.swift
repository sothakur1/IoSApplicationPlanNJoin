//
//  UserProfileEditView.swift
//  PlanNJoin
//
//  Created by Yash Patel on 4/22/24.
//

import SwiftUI

struct UserProfileEditView: View {
    @ObservedObject var viewModel: UserProfileEditViewModel = UserProfileEditViewModel()
    @EnvironmentObject var authViewModel: AuthenticationViewModel
    @State private var showingImagePicker = false

    var body: some View {
        ScrollView {
            VStack {
                Button(action: {
                    showingImagePicker = true
                }) {
                    Image(uiImage: viewModel.profileImage ?? UIImage(systemName: "person.fill")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 100, height: 100)
                        .clipShape(Circle())
                        .padding()
                }
                .sheet(isPresented: $showingImagePicker) {
                    ImagePicker(image: $viewModel.profileImage)
                }

                TextField("Username", text: $viewModel.username)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()

                TextField("Bio", text: $viewModel.bio)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()

                TextField("Phone Number", text: $viewModel.phoneNumber)
                    .keyboardType(.phonePad)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()

                DatePicker("Date of Birth", selection: Binding(get: {
                    DateFormatter.dateFromString(viewModel.dateOfBirth)
                }, set: { date in
                    viewModel.dateOfBirth = DateFormatter.stringFromDate(date)
                }), displayedComponents: .date)
                .padding()

                Button("Save Profile") {
                    viewModel.saveProfileData(image: viewModel.profileImage)
                }
                .padding()
                .foregroundColor(.white)
                .background(Color.blue)
                .clipShape(Capsule())

                Button(action: authViewModel.logOut) {
                    Text("Log Out")
                }
                .padding()
                .foregroundColor(.red)
                .background(Color.black)
                .clipShape(Capsule())
            }
            .background(Color.blue.opacity(0.2))
            //.navigationBarTitle("Edit Profile")
            .onAppear {
                viewModel.fetchUserProfile()
            }
        }
    }
}

extension DateFormatter {
    static func dateFromString(_ string: String) -> Date {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        return dateFormatter.date(from: string) ?? Date()
    }

    static func stringFromDate(_ date: Date) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        return dateFormatter.string(from: date)
    }
}
