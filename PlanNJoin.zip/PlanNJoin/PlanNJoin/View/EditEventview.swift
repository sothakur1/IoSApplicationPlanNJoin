//
//  EditEventview.swift
//  PlanNJoin
//
//  Created by Rahul Ravikanti on 5/3/24.
//

import Foundation
import SwiftUI

struct EditEventView: View {
    @ObservedObject var viewModel: EditEventViewModel

    var body: some View {
        ScrollView {
            VStack(alignment: .leading) {
                TextField("Event Title", text: $viewModel.event.title)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()

                DatePicker("Date", selection: $viewModel.event.dateTime, displayedComponents: .date)
                    .padding()

                TextEditor(text: $viewModel.event.description)
                    .frame(height: 200)
                        .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.gray, lineWidth: 1))
                    .padding()

                Section(header: Text("Attendees").font(.headline).padding(.top)) {
                    ForEach($viewModel.attendees, id: \.self) { $attendee in
                        TextField("Attendee Email", text: $attendee)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                    }
                    Button("Add Attendee") {
                        viewModel.addAttendee(email: "")
                    }
                    .padding()
                }

                Section(header: Text("Tasks").font(.headline).padding(.top)) {
                    ForEach($viewModel.tasks, id: \.id) { $task in
                        VStack {
                            TextField("Task Title", text: $task.title)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                            TextField("Assigned To", text: Binding.nonEmptyString($task.assignedTo))
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                            TextField("Description", text: $task.description)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                            Toggle("Completed", isOn: $task.isCompleted)
                        }
                        .padding()
                    }
                    Button("Add Task") {
                        viewModel.addTask(title: "New Task")
                    }
                    .padding()
                }
                HStack{
                    Spacer()
                    Button("Save Changes") {
                            viewModel.saveEventChanges()
                        }
                        .padding()
                        .foregroundColor(.white)
                        .background(Color.green)
                        .cornerRadius(8)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                    Spacer()
                }
                    
                            }
                        }
                        .background(Color.blue.opacity(0.2))
                        .navigationTitle("Edit Event")
                    }
                }

                struct EditEventView_Previews: PreviewProvider {
                    static var previews: some View {
                        EditEventView(viewModel: EditEventViewModel(event: Event(id: "1", title: "Sample Event", category: nil, location: "Virtual", dateTime: Date(), isPublic: true, description: "Event Description", tasks: [], attendeeEmails: ["example@email.com"])))
                    }
                }

                extension Binding where Value == String? {
                    /// Creates a binding that converts ⁠ nil ⁠ to an empty string and back, for optional String handling in SwiftUI views.
                    static func nonEmptyString(_ source: Binding<String?>) -> Binding<String> {
                        Binding<String>(
                            get: { source.wrappedValue ?? "" },
                            set: { source.wrappedValue = $0.isEmpty ? nil : $0 }
                        )
                    }
                }


