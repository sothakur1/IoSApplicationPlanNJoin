//
//  EventCreationView.swift
//  PlanNJoin
//
//  Created by Yash Patel on 4/10/24.
//

import SwiftUI

struct EventCreationView: View {
    @Environment(\.presentationMode) var presentationMode
    @ObservedObject var viewModel: EventCreationViewModel
    @EnvironmentObject var authViewModel: AuthenticationViewModel
    
    init(authViewModel: AuthenticationViewModel) {
            self.viewModel = EventCreationViewModel(authViewModel: authViewModel)
        }

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Event Details")) {
                    TextField("Title", text: $viewModel.title)
                    Picker("Category", selection: $viewModel.selectedCategoryID) {
                        ForEach(viewModel.categories, id: \.id) { category in
                            Text(category.name).tag(category.id as Optional<String>)
                        }
                    }
                    TextField("Location", text: $viewModel.location)
                    DatePicker("Date and Time", selection: $viewModel.dateTime, displayedComponents: [.date, .hourAndMinute])
                    Toggle("Public Event", isOn: $viewModel.isPublic)
                    TextField("Description", text: $viewModel.description)
                }

                Section(header: Text("Attendees")) {
                    TextField("Add Attendee Email", text: $viewModel.attendeeEmail)
                    Button("Add") {
                        if !viewModel.attendeeEmail.isEmpty {
                            viewModel.attendeeEmails.append(viewModel.attendeeEmail)
                            viewModel.attendeeEmail = ""
                        }
                    }
                    ForEach(viewModel.attendeeEmails, id: \.self) { email in
                        Text(email)
                    }
                }

                Section(header: Text("Tasks")) {
                    TextField("Task Title", text: $viewModel.taskTitle)
                    TextField("Assigned To", text: $viewModel.assignedTo)
                    TextField("Description", text: $viewModel.taskDescription)
                    Button("Add Task") {
                        let newTask = Task(id: UUID().uuidString, title: viewModel.taskTitle, assignedTo: viewModel.assignedTo, description: viewModel.taskDescription, isCompleted: false)
                        viewModel.localTasks.append(newTask)
                        viewModel.addTaskToFirestore(task: newTask)
                        viewModel.taskTitle = ""
                        viewModel.assignedTo = ""
                        viewModel.taskDescription = ""
                    }
                    ForEach(viewModel.localTasks, id: \.id) { task in
                        VStack(alignment: .leading) {
                            Text(task.title).font(.headline)
                            Text("Assigned to: \(task.assignedTo ?? "N/A")")
                            Text(task.description)
                        }
                    }
                }

                Button("Create Event") {
                    viewModel.createEvent()
                }
            }
        }
        .background(Color.blue.opacity(0.2))
        .navigationBarTitle("New Event")
    }
}
