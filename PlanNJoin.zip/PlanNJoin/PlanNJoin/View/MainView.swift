//
//  MainView.swift
//  PlanNJoin
//
//  Created by Yash Patel on 4/16/24.
//


import Foundation
import SwiftUI
struct MainView: View {
    @EnvironmentObject var authViewModel: AuthenticationViewModel
    
    var body: some View {
        
            
            TabView {
                HomeView()
                    .tabItem {
                        Label("Home", systemImage: "house.fill")
                    }
                EventCreationView(authViewModel: authViewModel)
                    .tabItem {
                        Label("Create Event", systemImage: "plus.circle")
                    }

                JoinEventView(authViewModel: authViewModel)
                    .tabItem {
                        Label("Join Event", systemImage: "person.3.fill")
                    }
                ClickNManageView()
                    .tabItem{
                        Label("manage Event", systemImage: "pencil")
                    }

                TasksView()
                    .tabItem {
                        Label("My Tasks", systemImage: "list.bullet")
                    }

                
            }
    
    }
}
 


struct MainView_Previews: PreviewProvider {
    static var previews: some View {
        let authViewModel = AuthenticationViewModel()
        
        return MainView()
            .environmentObject(authViewModel)
    }
}


