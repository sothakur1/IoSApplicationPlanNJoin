//
//  MovieHListView.swift
//  PlanNJoin
//
//  Created by Rahul Ravikanti on 5/1/24.
//

import Foundation
import SwiftUI

struct MovieHListView: View {
    @ObservedObject var myMovie = MovieListViewModel(category: MovieCategory.nowPlaying)
    
    var body: some View {
        NavigationView {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 10) {
                    ForEach(myMovie.movies) { movie in
                        NavigationLink(destination: MovieDetailView(movie: movie)) {
                            MovieRowView(movie: movie)
                        }
                        .buttonStyle(PlainButtonStyle()) // Prevents the default button style from interfering with the layout
                    }
                }
                .padding(.horizontal)
            }
            
            //.navigationTitle("Now Playing")
        }
        .onAppear {
            myMovie.fetchMovies()
        }
    }
}

struct MovieHListView_Previews: PreviewProvider {
    static var previews: some View {
        MovieHListView()
    }
}

