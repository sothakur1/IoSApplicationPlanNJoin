//
//  MovieRowView.swift
//  PlanNJoin
//
//  Created by Rahul Ravikanti on 5/1/24.
//

import Foundation
import SwiftUI

struct MovieRowView: View {
    var movie: Movie

    var body: some View {
        VStack(alignment: .center) {
            // Image loading and rendering block
            if let posterPath = movie.posterPath, let url = URL(string: "https://image.tmdb.org/t/p/w500\(posterPath)") {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .empty:
                        ProgressView()
                            .frame(width: 100, height: 100)
                    case .success(let image):
                        image.resizable()
                             .aspectRatio(contentMode: .fill)
                             .frame(width: 100, height: 100)
                             .cornerRadius(6)
                    case .failure:
                        Image(systemName: "film")
                            .font(.title)
                            .frame(width: 100, height: 100)
                            .cornerRadius(6)
                            .background(Color.gray.opacity(0.3)) // Optional: adds a background color for failed images
                    @unknown default:
                        EmptyView()
                    }
                }
            } else {
                Image(systemName: "film")
                    .font(.title)
                    .frame(width: 100, height: 100)
                    .cornerRadius(6)
                    .background(Color.gray.opacity(0.3)) // Consistent background for missing images
            }

            Text(movie.title)
                .fontWeight(.medium)
                .lineLimit(2) // Limit to 2 lines to prevent excessive height variation
                .multilineTextAlignment(.center)
                .frame(width: 100, height: 36) // Fixed height to ensure alignment regardless of text length
                .truncationMode(.tail) // Ensure text doesn't overflow visually
        }
        .frame(width: 100, height: 120) // Adjusted overall frame size
        .padding(.vertical, 8) // Reduced vertical padding for tighter spacing
    }
}
