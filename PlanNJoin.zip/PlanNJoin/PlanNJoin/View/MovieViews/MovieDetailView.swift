//
//  MovieDetailView.swift
//  PlanNJoin
//
//  Created by Rahul Ravikanti on 5/1/24.
//

import Foundation
import SwiftUI

struct MovieDetailView: View {
    var movie: Movie
    @State private var lastSelectedMovieID: Int? = UserDefaults.standard.integer(forKey: "LastSelectedMovieID")

    var body: some View {
        ScrollView {
            VStack(alignment: .leading) {  // Align content to the leading edge
                movieImages
                    .padding(.bottom)

                movieTitle
                movieRating
                    .padding(.vertical)

                movieOverview
                Spacer()
            }
            .padding(.horizontal)  // Add horizontal padding for the entire VStack
        }
        .background(Color.blue.opacity(0.2))
        .navigationTitle(movie.title)
        .navigationBarTitleDisplayMode(.inline)
    }
         
    
    @ViewBuilder
    private var movieImages: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 10) {
                ForEach([movie.posterPath, movie.backdropPath], id: \.self) { imagePath in
                    if let imagePath = imagePath, let url = URL(string: "https://image.tmdb.org/t/p/w500\(imagePath)") {
                        AsyncImage(url: url) { image in
                            image.resizable()
                                 .scaledToFit()
                        } placeholder: {
                            ProgressView()
                        }
                        .frame(height: 200)
                        .cornerRadius(10)
                    }
                }
                ForEach([movie.posterPath, movie.backdropPath], id: \.self) { imagePath in
                    if let imagePath = imagePath, let url = URL(string: "https://image.tmdb.org/t/p/w500\(imagePath)") {
                        AsyncImage(url: url) { image in
                            image.resizable()
                                 .scaledToFit()
                        } placeholder: {
                            ProgressView()
                        }
                        .frame(height: 200)
                        .cornerRadius(10)
                    }
                }
            }
        }
    }
    
    private var movieTitle: some View {
        Text(movie.title)
            .font(.title2)
            .fontWeight(.bold)
            .padding(.top)
    }
    
    private var movieRating: some View {
        let percentage = min(max(0, movie.voteAverage), 10) * 10 // Convert voteAverage to percentage
        let color: Color

        if percentage >= 75 {
            color = .green
        } else if percentage >= 50 {
            color = .yellow
        } else {
            color = .red
        }

        return HStack(spacing: 5) {
            Text("Rating")
                .fontWeight(.semibold)
            ZStack {
                Circle()
                    .stroke(Color.gray.opacity(0.3), lineWidth: 2)
                    .frame(width: 50, height: 50) // Reduced lineWidth
                Circle()
                    .trim(from: 0, to: CGFloat(percentage) / 100)
                    .stroke(color, style: StrokeStyle(lineWidth: 3, lineCap: .round, lineJoin: .round)) // Reduced lineWidth
                    .rotationEffect(Angle(degrees: -90))
                    .frame(width: 50, height: 50)
                Text("\(Int(percentage))%")
                        .fontWeight(.semibold)
                        .foregroundColor(color)
            }
        }
        .padding(.vertical, 5)
    }
    
    private var movieOverview: some View {
        Text(movie.overview)
            .padding(.vertical)
    }
}
