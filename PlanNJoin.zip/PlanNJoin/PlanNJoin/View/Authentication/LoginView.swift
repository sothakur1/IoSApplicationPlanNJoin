import SwiftUI

struct LoginView: View {
    @ObservedObject var viewModel: AuthenticationViewModel
    
    var body: some View {
        /*
         VStack{
             Text("PlanNJoin")
                 .font(.custom("HelveticaNeue-Bold", size: 40)) // Use a custom font with bold style
                 .foregroundColor(Color.blue) // Set text color to blue
                 .padding() // Add some padding around the text
                 .background(Color.yellow) // Set background color to yellow
                 .cornerRadius(10) // Apply corner radius to create a rounded rectangle background
                 .shadow(color: Color.gray, radius: 3, x: 0, y: 2) //
             Spacer()
         }
         */
        
         VStack(spacing: 20) {
             Text("Login")
                 .font(.largeTitle)
                 .fontWeight(.heavy)
                 .foregroundColor(.blue) // Set text color
             
             TextField("Email", text: $viewModel.email)
                 .textFieldStyle(RoundedBorderTextFieldStyle())
                 .padding(.horizontal, 20) // Add horizontal padding
                 .padding(.vertical, 10) // Add vertical padding
                 .autocapitalization(.none)
                 .keyboardType(.emailAddress)
                 .foregroundColor(.black) // Set text color
             
             SecureField("Password", text: $viewModel.password)
                 .textFieldStyle(RoundedBorderTextFieldStyle())
                 .padding(.horizontal, 20)
                 .padding(.vertical, 10)
                 .foregroundColor(.black)
             
             Button("Login") {
                 viewModel.login()
             }
             .frame(maxWidth: .infinity) // Expand button to full width
             .padding(.horizontal, 20)
             .padding(.vertical, 10)
             .foregroundColor(.white) // Set text color
             .background(Color.blue) // Set background color
             .cornerRadius(8) // Round button corners
             
             NavigationLink(destination: SignupView(viewModel: viewModel)) {
                 Text("Don't have an account? Sign up")
                     .foregroundColor(.blue)
             }
             .padding(.top, 10)
         }
         .cornerRadius(20)
         .background(Color.blue.opacity(0.2))
         .padding()
        
    }
        
}

struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            LoginView(viewModel: AuthenticationViewModel())
        }
    }
}
