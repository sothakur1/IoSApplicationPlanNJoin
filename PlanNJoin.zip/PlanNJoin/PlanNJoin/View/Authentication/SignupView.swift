//
//  SignupView.swift
//  PlanNJoin
//
//  Created by Yash Patel on 3/19/24.
//

// SignupView.swift

import SwiftUI

struct SignupView: View {
    @ObservedObject var viewModel: AuthenticationViewModel
    @State private var profileImage: Image? = nil
    @State private var name: String = ""
    @State private var phoneNumber: String = ""

    var body: some View {
        Spacer()
        VStack{
            Text("PlanNJoin")
                .font(.custom("HelveticaNeue-Bold", size: 40)) // Use a custom font with bold style
                .foregroundColor(Color.blue) // Set text color to blue
                .padding() // Add some padding around the text
                .background(Color.yellow) // Set background color to yellow
                .cornerRadius(10) // Apply corner radius to create a rounded rectangle background
                .shadow(color: Color.gray, radius: 3, x: 0, y: 2) //
        }
        Spacer()
        VStack {
            TextField("Email", text: $viewModel.email)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()

            SecureField("Password", text: $viewModel.password)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()

            Button("Sign Up") {
                viewModel.signUp()
            }
            .padding()   
        }
        .background(Color.blue.opacity(0.2))
        .cornerRadius(20)
        Spacer()
    }
   
}

struct SignupView_Previews: PreviewProvider {
    static var previews: some View {
        SignupView(viewModel: AuthenticationViewModel())
    }
}
