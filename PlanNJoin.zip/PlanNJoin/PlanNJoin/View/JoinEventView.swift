//
//  EventListView.swift
//  PlanNJoin
//
//  Created by Yash Patel on 4/10/24.
//
import SwiftUI
import FirebaseFirestoreSwift

struct JoinEventView: View {
    @EnvironmentObject var authViewModel: AuthenticationViewModel
    @ObservedObject var viewModel: JoinEventViewModel
    @ObservedObject var EDViewModel: EventDetailsViewModel

    init(authViewModel: AuthenticationViewModel) {
        self.viewModel = JoinEventViewModel(authViewModel: authViewModel)
        self.EDViewModel = EventDetailsViewModel()
    }

    var body: some View {
        NavigationView {
            List {
                ForEach(viewModel.events, id: \.id) { event in
                    HStack {
                        NavigationLink(destination: EventDetails(event: event, viewModel: EDViewModel)) {
                            VStack(alignment: .leading) {
                                Text(event.title).font(.headline)
                                Text(event.location)
                                Text("Date: \(event.dateTime, formatter: Self.dateFormatter)")
                            }
                        }
                        .buttonStyle(PlainButtonStyle())
                        Spacer()
                        if !event.attendeeEmails.contains(authViewModel.email) {
                            Button(action: {
                                viewModel.joinEvent(event)
                            }) {
                                Text("Join")
                                    .foregroundColor(.white)
                                    .padding(.horizontal)
                                    .background(Color.blue)
                                    .cornerRadius(10)
                            }
                            .buttonStyle(PlainButtonStyle())
                        }
                    }
                }
            }
            .background(Color.blue.opacity(0.2))
            .navigationBarTitle("Join Events")
            .onAppear(perform: viewModel.loadEvents)
            .alert(isPresented: $viewModel.showAlert) {
                Alert(title: Text("Error"), message: Text(viewModel.loadingError ?? "Unknown error"), dismissButton: .default(Text("OK")))
            }
        }
    }

    static let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter
    }()
}



//
//import SwiftUI
//import Firebase
//import FirebaseFirestoreSwift
//
//struct JoinEventView: View {
//    @EnvironmentObject var authViewModel: AuthenticationViewModel
//    @State private var events: [Event] = []
//    @State private var loadingError: String?
//    @State private var showAlert: Bool = false
//
//    var body: some View {
//        NavigationView {
//            List {
//                ForEach(events, id: \.id) { event in
//                    HStack {
//                        NavigationLink(destination: EventDetailView(event: event, authViewModel: _authViewModel)) {
//                            VStack(alignment: .leading) {
//                                Text(event.title).font(.headline)
//                                Text(event.location)
//                                Text("Date: \(event.dateTime, formatter: Self.dateFormatter)")
//                            }
//                        }
//                        .buttonStyle(PlainButtonStyle())  // This ensures that the navigation link doesn't trigger when clicking the Join button
//                        Spacer()
//                        if !event.attendeeEmails.contains(authViewModel.email) {
//                            Button(action: {
//                                joinEvent(event)
//                            }) {
//                                Text("Join")
//                                    .foregroundColor(.white)
//                                    .padding(.horizontal)
//                                    .background(Color.blue)
//                                    .cornerRadius(10)
//                            }
//                            .buttonStyle(PlainButtonStyle())  // Make the button explicitly styled to avoid unwanted effects
//                        }
//                    }
//                }
//            }
//            .navigationBarTitle("Join Events")
//            .onAppear(perform: loadEvents)
//            .alert(isPresented: $showAlert) {
//                Alert(title: Text("Error"), message: Text(loadingError ?? "Unknown error"), dismissButton: .default(Text("OK")))
//            }
//        }
//    }
//
//    private func loadEvents() {
//        let db = Firestore.firestore()
//        let today = Date()
//        db.collection("events")
//            .whereField("isPublic", isEqualTo: true)
//            .whereField("dateTime", isGreaterThan: today)
//            .order(by: "dateTime", descending: false)
//            .getDocuments { (querySnapshot, error) in
//                if let error = error {
//                    self.loadingError = "Failed to fetch events: \(error.localizedDescription)"
//                    self.showAlert = true
//                } else if let documents = querySnapshot?.documents, !documents.isEmpty {
//                    self.events = documents.compactMap { document -> Event? in
//                        try? document.data(as: Event.self)
//                    }.filter { !$0.attendeeEmails.contains(self.authViewModel.email) }
//                    if self.events.isEmpty {
//                        self.loadingError = "No events available to join."
//                        self.showAlert = true
//                    }
//                } else {
//                    self.loadingError = "No events found in the database."
//                    self.showAlert = true
//                }
//            }
//    }
//
//    private func joinEvent(_ event: Event) {
//        guard let eventId = event.id else {
//            self.loadingError = "Event does not have a valid ID."
//            self.showAlert = true
//            return
//        }
//
//        let db = Firestore.firestore()
//        db.collection("events").document(eventId).updateData([
//            "attendeeEmails": FieldValue.arrayUnion([authViewModel.email])
//        ]) { error in
//            if let error = error {
//                self.loadingError = "Failed to join event: \(error.localizedDescription)"
//                self.showAlert = true
//            } else {
//                print("User added to event successfully")
//                self.loadEvents()  // Refresh the events list to reflect the new state
//            }
//        }
//    }
//
//    static let dateFormatter: DateFormatter = {
//        let formatter = DateFormatter()
//        formatter.dateStyle = .medium
//        formatter.timeStyle = .short
//        return formatter
//    }()
//}
//
