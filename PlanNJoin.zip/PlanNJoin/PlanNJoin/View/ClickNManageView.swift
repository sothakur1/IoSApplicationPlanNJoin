//
//  ClickNManageView.swift
//  PlanNJoin
//
//  Created by Rahul Ravikanti on 5/3/24.
//

import Foundation
import SwiftUI

struct ClickNManageView: View {
    @ObservedObject var viewModel = ManageEventViewModel()
    @EnvironmentObject var authViewModel: AuthenticationViewModel
    

    var body: some View {
        NavigationView {
            List {
                Section(header: Text("Scheduled Public Events")) {
                    ForEach(viewModel.events.filter { $0.isPublic }) { event in
                        EventRow(event: event)
                    }
                }
                
                Section(header: Text("Scheduled Private Events")) {
                    ForEach(viewModel.events.filter { !$0.isPublic }) { event in
                        EventRow(event: event)
                    }
                }
            }
            .navigationTitle("Click N Manage")
            .onAppear {
                viewModel.loadEventsByEmail()
            }
        }
    }
}

/*
 struct EventRow: View {
     var event: Event
     @StateObject var eventDetailsViewModel = EventDetailsViewModel()
     
     var body: some View {
         VStack(alignment: .leading) {
             HStack {
                 VStack(alignment: .leading) {
                     Text(event.title)
                         .font(.headline)
                     Text(event.location)
                         .font(.subheadline)
                 }
                 Spacer()
                 VStack(alignment: .trailing) {
                     Text(event.dateTime, style: .date)
                         .font(.caption)
                 }
             }
             .padding(.bottom, 1)

             HStack {
                 Button {

                 } label: {
                     NavigationLink(destination: EventDetails(event: event, viewModel: eventDetailsViewModel)) {
                         Text("Details")
                     }
                 }
                 Spacer()
                 NavigationLink(destination: EditEventView(viewModel: EditEventViewModel(event: event))) {
                     Text("Edit")
                 }

                 Spacer()
                 Button("Cancel") {
                     // Implement comment action
                 }
             }
             .padding(.top, 1)
         }
         .padding()
         .background(Color.white)
         .cornerRadius(10)
         .shadow(radius: 2)
     }
 }
 */


 struct EventRow: View {
     var event: Event
     @StateObject var eventDetailsViewModel = EventDetailsViewModel()
     
     var body: some View {
         VStack(alignment: .leading) {
             HStack {
                 VStack(alignment: .leading) {
                     Text(event.title)
                         .font(.headline)
                     Text(event.location)
                         .font(.subheadline)
                 }
                 Spacer()
                 VStack(alignment: .trailing) {
                     Text(event.dateTime, style: .date)
                         .font(.caption)
                 }
             }
             .padding(.bottom, 1)

             HStack {
                
                     NavigationLink(destination: EditEventView(viewModel: EditEventViewModel(event: event))) {
                         Text("Edit")
                     }
                 
                Spacer()

             }
             .padding(.top, 1)
         }
         .padding()
         .background(Color.blue.opacity(0.2))
         .cornerRadius(10)
         .shadow(radius: 2)
     }
 }

 

struct ClickNManageView_Previews: PreviewProvider {
    static var previews: some View {
        ClickNManageView()
    }
}
