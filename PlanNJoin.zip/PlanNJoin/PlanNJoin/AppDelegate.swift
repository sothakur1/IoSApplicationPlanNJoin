//
//  AppDelegate.swift
//  PlanNJoin
//
//  Created by Yash Patel on 3/19/24.
//

//import Foundation
//import SwiftUI
//import FirebaseCore
//
//class AppDelegate: NSObject, UIApplicationDelegate {
//
//  func application(_ application: UIApplication,
//                   didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
//      
//    FirebaseApp.configure()
//    return true
//  }
//}


import UIKit
import Firebase
import FirebaseAppCheck

class AppDelegate: NSObject, UIApplicationDelegate {
    
    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        
        // Set up Firebase AppCheck with a debug provider before initializing Firebase
        if isRunningInDebugMode() {
            let providerFactory = AppCheckDebugProviderFactory()
            AppCheck.setAppCheckProviderFactory(providerFactory)
        }
        
        // Configure Firebase
        FirebaseApp.configure()
        
        return true
    }
    
    /// Determines if the application is running in debug mode
    func isRunningInDebugMode() -> Bool {
        #if DEBUG
        return true
        #else
        return false
        #endif
    }
}

class AppCheckDebugProviderFactory: NSObject, AppCheckProviderFactory {
    func createProvider(with app: FirebaseApp) -> AppCheckProvider? {
        return AppCheckDebugProvider(app: app)
    }
}

class AppCheckDebugProvider: NSObject, AppCheckProvider {
    let app: FirebaseApp
    
    init(app: FirebaseApp) {
        self.app = app
    }
    
    func getToken(completion: @escaping (AppCheckToken?, Error?) -> Void) {
        // Create a fake token for development environments
        let fakeToken = AppCheckToken(token: "fake_app_check_token", expirationDate: Date().addingTimeInterval(60 * 60))
        completion(fakeToken, nil)
    }
}
