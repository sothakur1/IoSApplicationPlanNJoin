//
//  Event.swift
//  PlanNJoin
//
//  Created by Yash Patel on 4/10/24.
//

import Foundation
import FirebaseFirestoreSwift  // For Firestore Codable support

struct Event: Codable, Identifiable {
    @DocumentID var id: String?  // Automatically mapped Firestore document ID
    var title: String
    var category: Category?  // Make optional if not present in all documents
    var location: String
    var dateTime: Date
    var isPublic: Bool
    var description: String
    var tasks:[String]
    //var tasks: [Task]
    var attendeeEmails: [String]

    enum CodingKeys: String, CodingKey {
        case id
        case title
        case category
        case location
        case dateTime
        case isPublic
        case description
        case tasks
        case attendeeEmails
    }
}
