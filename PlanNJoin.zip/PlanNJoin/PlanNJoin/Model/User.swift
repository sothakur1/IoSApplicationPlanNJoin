//
//  User.swift
//  PlanNJoin
//
//  Created by Yash Patel on 4/10/24.
//

import Foundation

struct User: Codable, Identifiable {
    var id: String // Firestore document ID
    var name: String
    var profilePicture: String // URL to the user's profile picture
    var email: String // Email, likely used with Firebase Authentication
    var phoneNumber: String
}
