//
//  Category.swift
//  PlanNJoin
//
//  Created by Yash Patel on 4/10/24.
//

import Foundation

struct Category: Codable, Identifiable {
    var id: String // Document ID from Firestore
    var name: String
}
