//
//  MovieData.swift
//  PlanNJoin
//
//  Created by Rahul Ravikanti on 4/30/24.
//

import Foundation
struct Movie: Decodable, Identifiable {
    let id: Int
    let title: String
    let backdropPath: String?
    let posterPath: String?
    let overview: String
    let voteAverage: Double
    let releaseDate: String
    var isFavorite: Bool = false  // Default to false

    enum CodingKeys: String, CodingKey {
        case id, title, overview, voteAverage = "vote_average", releaseDate = "release_date"
        case backdropPath = "backdrop_path", posterPath = "poster_path"
    }
}
