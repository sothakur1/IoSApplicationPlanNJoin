//
//  ContentView.swift
//  PlanNJoin
//
//  Created by Yash Patel on 3/19/24.
//

// ContentView.swift

import SwiftUI
import SwiftUI

struct ContentView: View {
    @EnvironmentObject var viewModel: AuthenticationViewModel

    var body: some View {
        NavigationView {
            switch viewModel.isUserAuthenticated {
            case .undefined:
                ProgressView().navigationTitle("Loading...").navigationBarHidden(true)
            case .signedOut:
                if viewModel.isShowingSignup {
                    SignupView(viewModel: viewModel).navigationTitle("PlanNJoin").navigationBarHidden(false)
                } else {
                    LoginView(viewModel: viewModel).navigationTitle("PlanNJoin").navigationBarHidden(false)
                }
            case .signedIn:
                MainView().navigationBarHidden(false)
            }
        }
        .onAppear {
            viewModel.checkAuthentication()
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }
}

//struct MainView: View {
//    @EnvironmentObject var authViewModel: AuthenticationViewModel
//    
//    var body: some View {
//        NavigationView {
//            List {
//                NavigationLink(destination: EventCreationView()) {
//                    Text("Create New Event")
//                }
//                NavigationLink(destination: JoinEventView()) {
//                    Text("Join Events")
//                }
//            }
//            }
//            .navigationBarTitle("Dashboard")
//            .navigationBarItems(trailing: Button(action: authViewModel.logOut) {
//                Text("Log Out")
//            })
//        }
//    }


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .environmentObject(AuthenticationViewModel())
    }
}
