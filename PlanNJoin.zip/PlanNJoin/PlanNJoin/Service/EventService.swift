//
//  EventService.swift
//  PlanNJoin
//
//  Created by Yash Patel on 3/20/24.
//

import FirebaseFirestore
import FirebaseFirestoreSwift

struct EventService {
    private let db = Firestore.firestore()

    func createEvent(_ event: Event, completion: @escaping (Result<Void, Error>) -> Void) {
        do {
            try db.collection("events").addDocument(from: event) { error in
                if let error = error {
                    completion(.failure(error))
                } else {
                    completion(.success(()))
                }
            }
        } catch let error {
            completion(.failure(error))
        }
    }
}
