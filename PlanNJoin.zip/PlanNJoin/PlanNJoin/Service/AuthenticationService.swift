//
//  AuthenticationService.swift
//  PlanNJoin
//
//  Created by Yash Patel on 3/19/24.
//

import FirebaseAuth
import FirebaseFirestore  // Import Firestore

struct AuthenticationService {
    static let shared = AuthenticationService()
    private let db = Firestore.firestore()  // Firestore database reference
    
    func loginWithEmail(email: String, password: String, completion: @escaping (Result<FirebaseAuth.User, Error>) -> Void) {
        Auth.auth().signIn(withEmail: email, password: password) { authResult, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            guard let user = authResult?.user else {
                completion(.failure(NSError(domain: "AuthError", code: -1, userInfo: ["message": "Authentication failed."])))
                return
            }
            completion(.success(user))
        }
    }
    
    func signUpWithEmail(name: String, phoneNumber: String, email: String, password: String, completion: @escaping (Result<FirebaseAuth.User, Error>) -> Void) {
        Auth.auth().createUser(withEmail: email, password: password) { authResult, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            guard let user = authResult?.user else {
                completion(.failure(NSError(domain: "AuthError", code: -1, userInfo: ["message": "User creation failed."])))
                return
            }
            
            // Save additional user details in Firestore
            self.saveUserDetails(user: user, name: name, phoneNumber: phoneNumber, email: email) { saveResult in
                switch saveResult {
                case .success():
                    completion(.success(user))
                case .failure(let saveError):
                    completion(.failure(saveError))
                }
            }
        }
    }
    
    private func saveUserDetails(user: FirebaseAuth.User, name: String, phoneNumber: String, email: String, completion: @escaping (Result<Void, Error>) -> Void) {
        db.collection("users").document(user.uid).setData([
            "name": name,
            "profilePicture": "",  // Placeholder for profile picture URL
            "email": email,  // Consider security implications and potentially omit if sensitive
            "phoneNumber": phoneNumber
        ]) { error in
            if let error = error {
                completion(.failure(error))
            } else {
                completion(.success(()))
            }
        }
    }
}
